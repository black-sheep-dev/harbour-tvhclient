#ifndef TVHCLIENT_H
#define TVHCLIENT_H

#include <QObject>

#include <QNetworkAccessManager>

#include "models/channelsmodel.h"
#include "models/channelssortfiltermodel.h"

class TVHClient : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QString hostname READ hostname WRITE setHostname NOTIFY hostnameChanged)
    Q_PROPERTY(quint16 port READ port WRITE setPort NOTIFY portChanged)

public: 
    explicit TVHClient(QObject *parent = nullptr);
    ~TVHClient() override;

    Q_INVOKABLE ChannelsModel *channelsModel();
    Q_INVOKABLE ChannelsSortFilterModel *channelsSortFilterModel();
    Q_INVOKABLE void initialize();
    Q_INVOKABLE void saveSettings();

    // API CALLS
    Q_INVOKABLE void getChannels();
    Q_INVOKABLE void getEpgNow();

    // properties
    QString hostname() const;
    quint16 port() const;

signals:
    void hostnameChanged(const QString &hostname);
    void portChanged(quint16 port);

public slots:
    void setHostname(const QString &hostname);
    void setPort(quint16 port);

private slots:
    void parseReply(QNetworkReply *reply);

private:
    enum Request {
        RequestUndefined,
        RequestChannels,
        RequestEpgNow
    };

    QNetworkRequest getRequest(const QString &endpoint);
    QByteArray gunzip(const QByteArray &data);
    void readSettings();
    void writeSettings();

    ChannelsModel *m_channelsModel{new ChannelsModel(this)};
    ChannelsSortFilterModel *m_channelsSortFilterModel{new ChannelsSortFilterModel(this)};
    QNetworkAccessManager *m_manager{new QNetworkAccessManager(this)};

    // properties
    QString m_hostname;
    quint16 m_port{9981};
};

#endif // TVHCLIENT_H
